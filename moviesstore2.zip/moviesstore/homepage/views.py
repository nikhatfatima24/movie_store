#from django.shortcuts import render

# Create your views here.
from django.shortcuts import render

def index(request):
    template_data = {'title': 'Movies Store'}
    return render(request, 'homepage/index.html', {'template_data': template_data})

def about(request):
    template_data = {'title': 'About'}
    return render(request, 'homepage/about.html', {'template_data': template_data})

